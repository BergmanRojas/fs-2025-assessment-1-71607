using fs_2025_api_20250925_71607.Endpoints;
using fs_2025_api_20250925_71607.Startup;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.AddDependencies();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.AddWeatherEndPoints();
app.AddCourseEndPoints();
app.AddRootEndPoints();
app.AddBookEndPoints(); // <-- NUEVO

app.Run();